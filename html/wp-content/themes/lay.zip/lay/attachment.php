<?php 
global $post;
echo '<img src="'.$post->guid.'" alt="">';
?>