<?php
// types of menus:
define('PRIMARY_MENU', 'primary');
define('SECOND_MENU', 'second_menu');
define('THIRD_MENU', 'third_menu');
define('FOURTH_MENU', 'fourth_menu');
define('MOBILE_MENU', 'lay_mobile_menu');

define('PRIMARY_MENU_DESCRIPTION', 'Primary Menu');
define('SECOND_MENU_DESCRIPTION', 'Second Menu');
define('THIRD_MENU_DESCRIPTION', 'Third Menu');
define('FOURTH_MENU_DESCRIPTION', 'Fourth Menu');