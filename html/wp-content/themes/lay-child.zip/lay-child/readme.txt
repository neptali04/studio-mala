Thank your for using Lay Theme!

Find installation instructions here: http://laytheme.com/installation.html
Find a "getting started video" here: http://laytheme.com/getting-started.html
Find the docs here: http://laytheme.com/documentation.html