(function( $ ) {
 
    $(function() {
        $('.image-placeholder-color-picker').wpColorPicker();
        $('.lay-hr-color-picker').wpColorPicker();
    });
     
})( jQuery );