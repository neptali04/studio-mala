var laycarousel_showhide_settings = (function(){
	var stateMap = {
		circlesActive: null,
		cursors: null,
		transition: null,
		showCaptions: null,
		showNumbers: null
	};

	var initModule = function(){
		numbersIsChecked = jQuery('#laycarousel_showNumbers').is(':checked');
		captionsIsChecked = jQuery('#laycarousel_showCaptions').is(':checked');

		showhide_for_circles();
		jQuery('#laycarousel_showCircles').on('change', showhide_for_circles);

		showhide_for_cursors();
		jQuery('#laycarousel_mousecursor').on('change', showhide_for_cursors);

		showhide_for_transitiontype();
		jQuery('#laycarousel_transition').on('change', showhide_for_transitiontype);

		showhide_for_captions();
		jQuery('#laycarousel_showCaptions').on('change', showhide_for_captions);

		showhide_for_numbers();
		jQuery('#laycarousel_showNumbers').on('change', showhide_for_numbers);

		showhide_for_arrow_buttons();
		jQuery('#laycarousel_showArrowButtons').on('change', showhide_for_arrow_buttons);
	};

	var showhide_for_arrow_buttons = function(){
		var showArrowButtons = jQuery('#laycarousel_showArrowButtons').is(':checked');
		if(showArrowButtons){
			jQuery(document.getElementById('laycarousel_rightbutton_button').parentNode.parentNode).show();
			jQuery(document.getElementById('laycarousel_buttonspace').parentNode.parentNode).show();
		}else{
			jQuery(document.getElementById('laycarousel_rightbutton_button').parentNode.parentNode).hide();
			jQuery(document.getElementById('laycarousel_buttonspace').parentNode.parentNode).hide();
		}
	}

	var showhide_for_numbers = function(){
		stateMap.showNumbers = jQuery('#laycarousel_showNumbers').is(':checked');
		var array = ['laycarousel_spaceBetweenForNumbers', 'laycarousel_numbersPosition', 'laycarousel_numberTextformat']
		
		if(stateMap.showNumbers){
			for(i=0; i<array.length; i++){
				jQuery(document.getElementById(array[i]).parentNode.parentNode).show();
			}
		}
		else{
			for(i=0; i<array.length; i++){
				jQuery(document.getElementById(array[i]).parentNode.parentNode).hide();
			}
		}
	};

	var showhide_for_captions = function(){
		stateMap.showCaptions = jQuery('#laycarousel_showCaptions').is(':checked');
		var array = ['laycarousel_captionsPosition', 'laycarousel_captionTextformat', 'laycarousel_spaceBetween']

		if(stateMap.showCaptions){
			for(i=0; i<array.length; i++){
				jQuery(document.getElementById(array[i]).parentNode.parentNode).show();
			}
		}
		else{
			for(i=0; i<array.length; i++){
				jQuery(document.getElementById(array[i]).parentNode.parentNode).hide();
			}
		}
	};

	var showhide_for_transitiontype = function(){
		stateMap.transition = jQuery('#laycarousel_transition').val();
		if(stateMap.transition == "sliding"){
			if( jQuery('#laycarousel_mousecursor').val() == "pointer" ){
				jQuery('#laycarousel_mousecursor').val('leftright').trigger('change');
			}
			jQuery('#laycarousel_mousecursor option[value="grab"]').show();
			jQuery('#laycarousel_mousecursor option[value="pointer"]').hide();
		}
		else{
			if( jQuery('#laycarousel_mousecursor').val() == "grab" ){
				jQuery('#laycarousel_mousecursor').val('leftright').trigger('change');
			}
			jQuery('#laycarousel_mousecursor option[value="grab"]').hide();
			jQuery('#laycarousel_mousecursor option[value="pointer"]').show();
		}
	}

	var showhide_for_cursors = function(){
		stateMap.cursor = jQuery('#laycarousel_mousecursor').val();
		switch(stateMap.cursor){
			case 'leftright':
				jQuery(document.getElementById('laycarousel_arrowleft').parentNode.parentNode).show();
				jQuery(document.getElementById('laycarousel_arrowright').parentNode.parentNode).show();
			break;
			case 'right':
				jQuery(document.getElementById('laycarousel_arrowleft').parentNode.parentNode).hide();
				jQuery(document.getElementById('laycarousel_arrowright').parentNode.parentNode).show();
			break;
			default:
				jQuery(document.getElementById('laycarousel_arrowleft').parentNode.parentNode).hide();
				jQuery(document.getElementById('laycarousel_arrowright').parentNode.parentNode).hide();
			break;
		}
	}

	var numbersIsChecked = null;
	var captionsIsChecked = null;
	var showhide_for_circles = function(){
		stateMap.circlesActive = jQuery('#laycarousel_showCircles').is(':checked');
		if(stateMap.circlesActive){
			numbersIsChecked = jQuery('#laycarousel_showNumbers').is(':checked');
			captionsIsChecked = jQuery('#laycarousel_showCaptions').is(':checked');
			jQuery('#laycarousel_showNumbers').removeAttr('checked').attr('disabled', 'disabled');
			jQuery('#laycarousel_showCaptions').removeAttr('checked').attr('disabled', 'disabled');
		}else{
			jQuery('#laycarousel_showNumbers').removeAttr('disabled');
			if(numbersIsChecked){
				jQuery('#laycarousel_showNumbers').attr('checked', 'checked');
			}
			
			jQuery('#laycarousel_showCaptions').removeAttr('disabled');
			if(captionsIsChecked){
				jQuery('#laycarousel_showCaptions').attr('checked', 'checked');
			}
		}

		showhide_for_captions();
		showhide_for_numbers();

		if(stateMap.circlesActive){
			jQuery(document.getElementById('laycarousel_spaceBetweenForCircles').parentNode.parentNode).show();
		}
		else{
			jQuery(document.getElementById('laycarousel_spaceBetweenForCircles').parentNode.parentNode).hide();
		}		
	};

	return {
		initModule : initModule
	}
}());

jQuery(document).ready(function(){
	laycarousel_showhide_settings.initModule();
});