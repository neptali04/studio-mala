<div class="wrap">
    <h2>Carousel Addon</h2>

    <?php if(isset( $_GET['settings-updated'])) { ?>
	    <div class="updated">
	        <p>Settings updated successfully</p>
	    </div>
    <?php } ?>
	<div class="lay-explanation">
		<div class="lay-explanation-inner">
			<p>Add a carousel in the Gridder by clicking "+Carousel". You can activate the "autoplay" and "random order" options when you edit a carousel.</p>
			<p>A carousel will have the aspect ratio of its first image. You can also set a custom aspect ratio when you edit a carousel.</p>
		</div>
	</div>
	<form method="POST" action="options.php">
	<?php settings_fields( 'manage-laycarousel' );	//pass slug name of page, also referred
	                                        //to in Settings API as option group name
	do_settings_sections( 'manage-laycarousel' ); 	//pass slug name of page
	submit_button('Save Changes');
	?>
	</form>
</div>