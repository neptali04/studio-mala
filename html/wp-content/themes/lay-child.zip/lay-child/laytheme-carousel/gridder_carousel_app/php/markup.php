<?php
echo '<div id="carousel-modal" class="lay-input-modal"></div>';