<?php

class LayCover {

    public function __construct(){

    }

    public static function getMarkup() {
        
    }

}